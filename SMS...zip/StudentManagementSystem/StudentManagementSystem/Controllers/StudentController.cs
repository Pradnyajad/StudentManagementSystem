﻿using Microsoft.AspNetCore.Mvc;
using StudentManagementSystem.Models;
using StudentManagementSystem.Services;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;
using System.IO;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace StudentManagementSystem.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudentService _service;

        public StudentController(IStudentService service)
        {
            _service = service;
        }

        //  list of students
        public async Task<IActionResult> Index(string sortOrder, string searchString, string courseFilter, int pageNumber = 1)
        {
            int pageSize = 5;

            ViewBag.CurrentSort = sortOrder;
            ViewBag.CurrentSearch = searchString;
            ViewBag.CurrentCourse = courseFilter;

            var students = await _service.GetAllStudents();
            var studentQuery = students.AsQueryable();

            // 1️⃣ SEARCH by name
            if (!string.IsNullOrEmpty(searchString))
                studentQuery = studentQuery.Where(s => s.Name.Contains(searchString, StringComparison.OrdinalIgnoreCase));

            // filter by course
            if (!string.IsNullOrEmpty(courseFilter))
                studentQuery = studentQuery.Where(s => s.Course == courseFilter);

            // Sort by name
            studentQuery = sortOrder switch
            {
                "name_asc" => studentQuery.OrderBy(s => s.Name),
                "name_desc" => studentQuery.OrderByDescending(s => s.Name),
                _ => studentQuery.OrderBy(s => s.Id),
            };

            // Pagination
            int totalStudents = studentQuery.Count();
            ViewBag.TotalPages = (int)Math.Ceiling(totalStudents / (double)pageSize);
            ViewBag.PageNumber = pageNumber;

            var pagedStudents = studentQuery.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();

            // Course dropdown
            ViewBag.Courses = new SelectList(students.Select(s => s.Course).Distinct());

            // Sort dropdown
            ViewBag.SortOptions = new SelectList(new List<SelectListItem>
    {
        new SelectListItem { Value = "name_asc", Text = "Name A-Z" },
        new SelectListItem { Value = "name_desc", Text = "Name Z-A" }
    }, "Value", "Text", sortOrder);

            return View(pagedStudents);
        }

        // Create (GET)
        public IActionResult Create()
        {
            ViewBag.Courses = new SelectList(new List<string>
            { "Web Development", "DataScience", "Network Analyst", "Cyber Security", "Network Engineer", "Machine Learning" });
            return View();
        }

        // Create (POST)
        [HttpPost]
        public async Task<IActionResult> Create(Student student)
        {
            if (ModelState.IsValid)
            {
                await _service.AddStudent(student);
                return RedirectToAction("Index");
            }
            return View(student);
        }

        // Edit (GET)
        public async Task<IActionResult> Edit(int id)
        {
            var student = await _service.GetStudentById(id);
            ViewBag.Courses = new SelectList(
                new List<string> { "Web Development", "DataScience", "Network Analyst", "Cyber Security", "Network Engineer", "Machine Learning" },
                student.Course
            );
            return View(student);
        }

        // Edit (POST)
        [HttpPost]
        public async Task<IActionResult> Edit(Student student)
        {
            if (ModelState.IsValid)
            {
                await _service.UpdateStudent(student);
                return RedirectToAction("Index");
            }
            return View(student);
        }

        // Delete
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteStudent(id);
            return RedirectToAction("Index");
        }

        // uplaod excel (GET)
        public IActionResult UploadExcel() => View();

        // uplaod excel (POST)

        [HttpPost]
        public async Task<IActionResult> UploadExcel(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                ViewBag.ErrorMessage = "Please select a file to upload.";
                return View("Success");
            }

            var existingStudents = await _service.GetAllStudents();
            var existingEmails = existingStudents.Select(s => s.Email).ToList(); // emails in DB

            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);
                using (var workbook = new ClosedXML.Excel.XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet(1);
                    var rows = worksheet.RowsUsed().Skip(1); 

                    foreach (var row in rows)
                    {
                        var email = row.Cell(2).GetString().Trim();

                        if (existingEmails.Contains(email))
                        {
                            ViewBag.ErrorMessage = $"Upload failed! Email '{email}' already exists in database.";
                            return View("Success"); 
                        }
                    }

                    foreach (var row in rows)
                    {
                        var student = new Student
                        {
                            Name = row.Cell(1).GetString().Trim(),
                            Email = row.Cell(2).GetString().Trim(),
                            DateOfBirth = row.Cell(3).GetDateTime(),
                            Course = row.Cell(4).GetString().Trim(),
                            MobileNumber = row.Cell(5).GetString().Trim()
                        };

                        await _service.AddStudent(student);
                    }
                }
            }

            ViewBag.SuccessMessage = "File uploaded successfully!";
            return View("Success");
        }

        // export excel
        public async Task<IActionResult> ExportExcel()
        {
            var students = await _service.GetAllStudents();
            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("Students");
                worksheet.Cell(1, 1).Value = "Name";
                worksheet.Cell(1, 2).Value = "Email";
                worksheet.Cell(1, 3).Value = "Date Of Birth";
                worksheet.Cell(1, 4).Value = "Course";
                worksheet.Cell(1, 5).Value = "Mobile Number";

                int row = 2;
                foreach (var student in students)
                {
                    worksheet.Cell(row, 1).Value = student.Name;
                    worksheet.Cell(row, 2).Value = student.Email;
                    worksheet.Cell(row, 3).Value = student.DateOfBirth;
                    worksheet.Cell(row, 4).Value = student.Course;
                    worksheet.Cell(row, 5).Value = student.MobileNumber;
                    row++;
                }

                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    var content = stream.ToArray();
                    return File(
                        content,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "Students.xlsx"
                    );
                }
            }
        }
    }
}