﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StudentManagementSystem.Models;
using StudentManagementSystem.Repositories;

namespace StudentManagementSystem.Services
{
    public class StudentService : IStudentService
    {
        private readonly IStudentRepository _repository;

        public StudentService(IStudentRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Student>> GetAllStudents()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<Student> GetStudentById(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task AddStudent(Student student)
        {
            if (!await IsEmailUnique(student.Email))
            {
                throw new System.Exception("Email already exists");
            }

            await _repository.AddAsync(student);
        }

        public async Task UpdateStudent(Student student)
        {
            await _repository.UpdateAsync(student);
        }

        public async Task DeleteStudent(int id)
        {
            await _repository.DeleteAsync(id);
        }

        public async Task<bool> IsEmailUnique(string email)
        {
            var students = await _repository.GetAllAsync();
            return !students.Any(s => s.Email == email);
        }

        public async Task<IEnumerable<Student>> FilterStudents(string course)
        {
            var students = await _repository.GetAllAsync();

            if (string.IsNullOrEmpty(course))
                return students;

            return students.Where(s => s.Course == course);
        }
    }
}